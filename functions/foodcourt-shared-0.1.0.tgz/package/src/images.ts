/** Longest side of the small copy that menu lists load instead of the full dish photo. */
export const THUMB_SIDE = 240;

/**
 * Menu photos live at menus/<shop>/<name>.jpg and each has a small sibling, <name>-t.jpg. Lists load
 * the small one (about 10 KB instead of 150 KB). The link is built without the download token because
 * menu photos are publicly readable; null means this link has no small copy, so use the full photo.
 */
export function thumbUrlOf(imageUrl: string | null | undefined): string | null {
  if (!imageUrl) return null;
  try {
    const url = new URL(imageUrl);
    const match = /^(\/v0\/b\/[^/]+\/o\/)(.+)$/.exec(url.pathname);
    if (!match) return null;
    const path = decodeURIComponent(match[2] ?? '');
    if (!/^menus\/[^/]+\/[^/]+\.jpg$/.test(path) || path.endsWith('-t.jpg')) return null;
    return `${url.origin}${match[1]}${encodeURIComponent(path.replace(/\.jpg$/, '-t.jpg'))}?alt=media`;
  } catch {
    return null;
  }
}
